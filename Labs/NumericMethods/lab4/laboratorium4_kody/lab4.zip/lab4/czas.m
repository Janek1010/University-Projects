function [roznica] = czas(N)
  roznica = ((N^1.43+N^1.14)/1000) - 5000;
end