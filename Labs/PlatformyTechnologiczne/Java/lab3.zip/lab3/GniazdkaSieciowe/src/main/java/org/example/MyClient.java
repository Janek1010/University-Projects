package org.example;

import java.io.*;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyClient {
    private static final Logger LOGGER = Logger.getLogger(MyClient.class.getName());


    private Socket clientSocket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public static void main(String[] args) throws IOException, InterruptedException {
        MyClient client1 = new MyClient();
        client1.startConnection("127.0.0.1", 5555);
        var response1 = client1.sendMessage(new Message(3,"hej"));
        System.out.println(response1.getContent());

        var response = client1.sendMessage(new Message(5,"obiekty"));
        System.out.println(response.getContent());
//        while(true){
//            Thread.sleep(1000);
//        }
    }

    public void startConnection(String ip, int port) {
        try {
            clientSocket = new Socket(ip, port);
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            in = new ObjectInputStream(clientSocket.getInputStream());
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error when starting connection", e);
        }

    }

    public Message sendMessage(Message msg) {
        try {
            out.writeObject(msg);
            out.flush();
            return (Message) in.readObject();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error when sending connection", e);
            return null;
        }
    }

    public void stopConnection() {
        try {
            in.close();
            out.close();
            clientSocket.close();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error when closing connection", e);
        }

    }
}