import java.io.IOException;
public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        if (args.length == 0)
        {
            String path = System.getProperty("java.class.path");
            ProcessBuilder processBuilder = new ProcessBuilder("cmd", "/k", "start", "java", "-cp", path, "Main", "processInitiate", String.valueOf(3));
            processBuilder.inheritIO();
            Process process1 = processBuilder.start();

            int i = 1;
            while (i< 300)
            {

                System.out.println(ProcessHandle.current().pid() +" - " + i++);
                Thread.sleep(100);
            }
        }
        else
        {
            int howManyLeft = Integer.parseInt(args[1]);
            if (howManyLeft == 0) {
                return;
            }
            howManyLeft--;
            String path = System.getProperty("java.class.path");
            ProcessBuilder processBuilder = new ProcessBuilder("cmd", "/k", "start", "java", "-cp", path, "Main", "processInitiate", String.valueOf(howManyLeft));
            processBuilder.inheritIO();
            Process process1 = processBuilder.start();
            int i = 0;
            while (i <300)
            {;
                System.out.println(ProcessHandle.current().pid() +" - " + i++);
                Thread.sleep(100);
            }
        }
    }
}